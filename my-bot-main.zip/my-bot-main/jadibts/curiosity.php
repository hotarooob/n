<?php

$short_options = "Jadibots";

?>
