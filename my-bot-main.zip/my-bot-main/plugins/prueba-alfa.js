/*import yaoiImages from 'module-gatadios'

var handler = async (m, {conn, args, command, usedPrefix}) => {
  
const result = yaoiImages.getRandomImage('yaoi-hard', ['link', 'author', 'name', 'description'])
m.reply(`Autor: ${result.author}
Nombre: ${result.name}
Descripción: ${result.description}
Enlace: ${result.link}`)

}
handler.command = /^(prueba23)$/i
export default handler*/
