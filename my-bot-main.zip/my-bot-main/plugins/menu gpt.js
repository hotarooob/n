let handler = async (m, { conn }) => {
  let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
  let videoUrl = 'https://telegra.ph/file/21cbbd017324ee1f73ccd.mp4'
  let { name } = global.db.data.users[who]
  m.react('🤖')
let str = `【قـســم الـذكاء الاصطناعي】

🌀━━━━•^.🦇.^•━━━━🌀

❏..🤖╎❯ .بوت⌉
❏..🤖╎❯ .شوف⌉
❏..🤖╎❯ .ارسم⌉

🌀━━━━•^.🦇.^•━━━━🌀`
  conn.sendMessage(m.chat, {
           video: { url: videoUrl }, caption: str,
     mentions: [m.sender,global.conn.user.jid],
     gifPlayback: true,gifAttribution: 0
       }, { quoted: m });
   };

handler.help = ['main']
handler.tags = ['group']
handler.command = ['ذكاءاصطناعي']

export default handler
