yarn && npm start
