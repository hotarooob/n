import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath, pathToFileURL } from 'url'

global.owner = [['96176378749', '🪶الــوكـارد..♪', true], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749'], ['96176378749']]

//BETA: Si quiere evitar escribir el número que será bot en la consola, agregué desde aquí entonces:
//Sólo aplica para opción 2 (ser bot con código de texto de 8 digitos)
global.botNumberCode = '' //Ejemplo: +96176378749
global.confirmCode = ''

global.animxscans = ['96176378749']
global.suittag = ['96176378749']
global.mods = []
global.prems = []

global.packname = '『 96176378749+ 』'
global.author = '『 🪶الــوكـارد..♪ 』'
global.wm = '『 🪶الــوكـارد..♪ 』'
global.wm2 = '『 🪶الــوكـارد..♪ 』'
global.azami = '『 🪶الــوكـارد..♪ 』'
global.cb = '『 🪶الــوكـارد..♪ 』'

global.vs = 'V2 • 1.0.5'
global.library = 'Baileys'
global.baileys = '@whiskeysockets/baileys'
global.lenguaje = 'Español'
global.KMA = '╰━━━〔 *🛡️ 1.7.9* 〕━━━━━⬣'
global.menudi = ['⛶','❏','⫹⫺']
global.dev = '𝐀𝐋𝐔𝐂𝐀𝐑𝐃-BOT'
global.devnum = '+96176378749'

let file = fileURLToPath(import.meta.url)
watchFile(file, () => { unwatchFile(file)
console.log(chalk.yellow('Se actualizo el archivo config.js'))
import(`${file}?update=${Date.now()}`)
})
